// $(document).ready(function(){
//   $("h1").css("color","red");
// });
// $("h1").addClass("big-title backgroundColor");
// $("h1").removeClass("big-title");
//$("h1").hasClass("big-title"):----->True
// $("h1").text("bye");----> to update the html text
// $("button").text("Do'nt click me");----> to update the html text
// $("button.empty").text("Click Me");-----> to add text


//$("button").attr("name Of Attribute");----->value of attribute
//$("button").attr("name Of Attribute","value");-------> changing value of attribute


// $("h1").click(function(){
//   $("h1").css("color","purple");
// })
// for (var i = 0; i < $("button").length; i++) {
//     $("button")[i].addEventListener("click",function(){
//       $("h1").css("color","red");
//     })
// };
// $("button").click(function(){
//   $("h1").css("color","red");
// });

// $("body").keypress(function(event){
//   $("h1").text(event.key);
// });

// $("button").click(function(){
//   $("h1").fadeToggle();
// });

// $("button").click(function(){
//   $("h1").slideToggle();
// });

// $("button").click(function(){
//   $("h1").animate({opacity: 0.5});----------> only change the nummeric values
// });
